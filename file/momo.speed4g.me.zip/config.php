<?php
const DOMAINV2B = "speed4g.me";
const KEYWORD = "speed"; //viết thường
const TOKEN = "aJgqCsZiQ8Kki89bTQhCTaLlouOmp5JU6IVQeLxDlZR6TxaKvp";
const SIGNATIRE = "07d35483f9dbcc07bb01f35d3cf2274d4814f086deaf4d4d8469b257ca9bc74d";
const PHONE = "0368030503";
const WEBHOOK = "https://speed4g.me/api/v1/guest/payment/notify/MomoSv3/TJwWCLDK";